// script.js

// Toggle search bar visibility
document.getElementById('search-icon').addEventListener('click', function() {
    const searchInput = document.getElementById('search-input');
    searchInput.style.display = searchInput.style.display === 'block' ? 'none' : 'block';
});

// Automatic sliding for reviews
// const slides = document.querySelectorAll('.reviews .review');
// const indicators = document.querySelectorAll('.indicator');
// let currentIndex = 0;

// function showSlide(index) {
//     slides.forEach((slide, i) => {
//         slide.style.display = i === index ? 'flex' : 'none';
//     });
//     indicators.forEach((indicator, i) => {
//         indicator.classList.toggle('active', i === index);
//     });
// }

// function nextSlide() {
//     currentIndex = (currentIndex + 1) % slides.length;
//     showSlide(currentIndex);
//     // Reset slideshow to the beginning if indicators loop
//     if (currentIndex === 0) {
//         setTimeout(() => {
//             slides.forEach(slide => slide.style.display = 'none');
//             showSlide(0); // Ensure the first slide is shown
//         }, 3000); // Delay to match the interval
//     }
// }

// setInterval(nextSlide, 3000); // Change slide every 3 seconds


